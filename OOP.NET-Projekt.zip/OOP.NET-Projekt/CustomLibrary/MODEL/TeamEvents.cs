﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomLibrary.MODEL
{
    public class TeamEvents
    {
        public string TypeOfEvent { get; set; }
        public string Player { get; set; }
    }
}
