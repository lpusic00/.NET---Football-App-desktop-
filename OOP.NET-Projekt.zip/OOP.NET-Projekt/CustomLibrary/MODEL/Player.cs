﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomLibrary.MODEL
{
    public class Player :IComparable<Player>
    {
        public string Name { get; set; }
        public int ShirtNumber { get; set; }
        public string Position { get; set; }
        public bool FavPlayer { get; set; }
        public int NumberOfGoals { get; set; }
        public int NumberOfCards { get; set; }
        public int Appearance { get; set; }
        public int GameGoals { get; set; }
        public int GameCards { get; set; }
        private string cap;
        public string Captain
        {
            get{ return cap;}
            set
            {
                if (value.ToLower() == "false" || value == "")
                {
                    cap = "";
                }
                else
                {
                    cap = "Captain";
                }
            }
        }

        private string pic = REPO.DIR + @"\Pictures\default.png";
        public string Picture
        {
            get { return pic; }
            set { pic = value; }
        }

        public int CompareTo(Player other) => -NumberOfGoals.CompareTo(other.NumberOfGoals);

        public string FormatForFile() => $"{Name}|{ShirtNumber}|{Position}|{Captain}|{FavPlayer}|{NumberOfGoals}|{NumberOfCards}|{Appearance}|{Picture}";

        public static Player ParseFromFile(string line)
        {
            string[] details = line.Split('|');
            return new Player
            {
                Name = details[0],
                ShirtNumber = int.Parse(details[1]),
                Position = details[2],
                Captain = details[3],
                FavPlayer = bool.Parse(details[4]),
                NumberOfGoals = int.Parse(details[5]),
                NumberOfCards = int.Parse(details[6]),
                Appearance = int.Parse(details[7]),
                Picture = details[8]
            };
        }
    }
}
