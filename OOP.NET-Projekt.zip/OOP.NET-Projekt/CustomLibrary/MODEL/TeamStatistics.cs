﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomLibrary.MODEL
{
    public class TeamStatistics
    {
        private const string PATH = @"\NationalTeam.txt";

        public List<Player> StartingEleven { get; set; }
        public List<Player> Substitutes { get; set; }

        public List<Player> ListOfPlayers(string FifaCode)
        {
            List<Player> collectionOfPlayers = StartingEleven;
            collectionOfPlayers.AddRange(Substitutes);
            collectionOfPlayers.Concat(Substitutes);
            List<Game> games = REPO.GetGames(FifaCode);
            foreach (var g in games)
            {
                if (g.AwayTeam.Code == REPO.Load(PATH))
                {
                    foreach (var startingPlayer in g.AwayTeamStatistics.StartingEleven)
                    {
                        SetAppearance(startingPlayer.Name, collectionOfPlayers);
                    }
                    foreach (var teamEvent in g.AwayTeamEvents)
                    {
                        FillFiles(teamEvent, collectionOfPlayers);
                    }
                }
                else
                {
                    foreach (var startingPlayer in g.HomeTeamStatistics.StartingEleven)
                    {
                        SetAppearance(startingPlayer.Name, collectionOfPlayers);
                    }
                    foreach (var teamEvent in g.HomeTeamEvents)
                    {
                        FillFiles(teamEvent, collectionOfPlayers);
                    }
                }
            }

            return collectionOfPlayers;
        }

        private void SetAppearance(string name, List<Player> collection)
        {
            foreach (var igrac in collection)
            {
                if (igrac.Name == name)
                {
                    igrac.Appearance++;
                }
            }
        }

        private void FillFiles(TeamEvents teamEvent, List<Player> collection)
        {
            foreach (var player in collection)
            {
                if (player.Name == teamEvent.Player)
                {
                    if (teamEvent.TypeOfEvent == "goal" || teamEvent.TypeOfEvent == "goal-penalty")
                    {
                        player.NumberOfGoals++;
                    }
                    else if (teamEvent.TypeOfEvent == "yellow-card" || teamEvent.TypeOfEvent == "red-card")
                    {
                        player.NumberOfCards++;
                    }
                    else if (teamEvent.TypeOfEvent == "substitution-in")
                    {
                        player.Appearance++;
                    }
                }
            }
        }
    }
}
