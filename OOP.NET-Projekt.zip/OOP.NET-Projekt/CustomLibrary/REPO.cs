﻿using CustomLibrary.MODEL;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace CustomLibrary
{
    public class REPO
    {
        public const string DIR = @"C:\Users\lukap\Desktop\OOP.NET\OOP.NET-Projekt";
        private const string PATHplayers = DIR + @"\Players.txt";

        public static List<NationalTeam> GetNationalTeams()
        {
            var client = new RestClient("http://worldcup.sfg.io");

            var response = client.Execute<List<NationalTeam>>(new RestRequest("/teams/results", Method.GET));

            return response.Data;
        }

        public static NationalTeam GetNationalTeam(string FifaCode)
        {
            List<NationalTeam> list = GetNationalTeams();

            foreach (var item in list)
            {
                if (FifaCode == item.FifaCode)
                {
                    return item;
                }
            }
            return null;
        }
        //-wpf
        public static NationalTeam GetNationalTeamWPF(string FifaCode, List<NationalTeam> nationalTeams)
        {
            foreach (var i in nationalTeams)
            {
                if (FifaCode == i.FifaCode)
                {
                    return i;
                }
           }
            return null;
        }

        public static List<Player> GetPlayers(string FifaCode)
        {
            List<Game> listOfGames = GetGames(FifaCode);

            List<Player> playerCollection = listOfGames.First().GetTeamStatistics(FifaCode).ListOfPlayers(FifaCode);
           
            return playerCollection;
        }


        public static List<Game> GetGames(string FifaCode)
        {
            var client = new RestClient("http://worldcup.sfg.io");

            var response = client.Execute<List<Game>>
                (new RestRequest("/matches/country", Method.GET)
                .AddParameter("fifa_code", FifaCode));

            return response.Data;
        }

        public static void Save(string FifaCode, string path)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(DIR + path))
                {
                    writer.WriteLine(FifaCode);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();
            }
        }

        public static string Load(string path)
        {
            string line = null;
            using (StreamReader r = new StreamReader(DIR + path))
            {
                line = r.ReadLine();
            }
            return line;
        }

        public static bool CheckIfFileExists(string path)
        {
            if (File.Exists(DIR + path))
            {
                return true;
            }
            return false;
        }

        public static void SetLanguage(string lang)
        {
            Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo(lang);
            Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo(lang);
        }

        public static List<Player> LoadPlayers()
        {
            List<Player> pl = new List<Player>();
            string[] lines = File.ReadAllLines(PATHplayers);

            lines.ToList().ForEach(line => pl.Add(Player.ParseFromFile(line)));
            return pl;
        }

        public static void SavePlayers(List<Player> player)
        {
            File.WriteAllLines(PATHplayers, player.Select(i => i.FormatForFile()));
        }

        //-wpf
        public static List<Player> GameStatistics(List<TeamEvents> events, List<Player> players)
        {
            foreach (var teamEvent in events)
            {
                foreach (var p in players)
                {
                    if (p.Name == teamEvent.Player)
                    {
                        if (teamEvent.TypeOfEvent == "goal" || teamEvent.TypeOfEvent == "goal-penalty")
                        {
                            p.GameGoals++;
                        }
                        else if (teamEvent.TypeOfEvent == "yellow-card")
                        {
                            p.GameCards++;
                        }
                    }
                }
            }
            return players;
        }
        //-wpf
        public static void WindowSize(string size, string path)
        {
            string lang = "";
            using (var sr = new StreamReader(DIR + @"\Language.txt"))
            {
                lang = sr.ReadLine();
            }
            Save(lang, @"\Language.txt");
            File.AppendAllText(DIR + path, size);
        }
        //-wpf
        public static string Size()
        {
            using (var sr = new StreamReader(DIR + @"\Language.txt"))
            {
                sr.ReadLine();
                return sr.ReadLine();
            }
        }

        public static void Delete()
        {
            File.Delete(PATHplayers);
        }

    }
}
