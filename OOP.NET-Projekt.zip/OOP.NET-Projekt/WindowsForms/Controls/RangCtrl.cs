﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CustomLibrary.MODEL;

namespace WindowsForms.Controls
{
    public partial class RangCtrl : UserControl
    {
        public RangCtrl(Player player, string crit)
        {
            InitializeComponent();
            Set(player, crit);
        }

        private void Set(Player player, string crit)
        {
            BackColor = Color.White;
            pbPic.ImageLocation = player.Picture;
            pbPic.SizeMode = PictureBoxSizeMode.StretchImage;

            lblName.Text = player.Name;
            lblAppearance.Text = "Appearance: " + player.Appearance.ToString();
            if (crit == "goals")
            {
                lblCrit.Text = "Goals: " + player.NumberOfGoals.ToString();
            }
            else
            {
                lblCrit.Text = "Caards: " + player.NumberOfCards.ToString();
            }
        }
    }
}
