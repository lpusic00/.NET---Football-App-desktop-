﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CustomLibrary;
using CustomLibrary.MODEL;
using System.IO;

namespace WindowsForms.Controls
{
    public partial class UserControl1 : UserControl
    {
        private string PIC = REPO.DIR + @"\Pictures\Fav.png";
        Player player;

        public UserControl1(Player pl)
        {
            InitializeComponent();
            Set(pl);
            player = pl;

        }

        private void Set(Player pl)
        {
            BackColor = Color.White;
            PlayerName.Text = pl.Name;
            Number.Text = pl.ShirtNumber.ToString();
            Position.Text = pl.Position;
            Captain.Text = pl.Captain;
            pbPic.ImageLocation = pl.Picture;
            pbPic.SizeMode = PictureBoxSizeMode.StretchImage;

            pbFav.ImageLocation = PIC;
            pbFav.SizeMode = PictureBoxSizeMode.StretchImage;
            if (!pl.FavPlayer == true)
            {
                pbFav.Hide();
            }
        }

        private void UserControl1_MouseDown(object sender, MouseEventArgs e)
        {
            UserControl1 uc;
            if (sender is Label)
            {
                uc = ((sender as Label).Parent) as UserControl1;
            }
            else
            {
                uc = sender as UserControl1;
                uc.DoDragDrop(this, DragDropEffects.Move);
            }     
        }

        private void pbPic_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Pictures|*.jpg;*.jpeg;*.png;*";
            PictureBox pb = sender as PictureBox;

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                player.Picture = REPO.DIR + @"\Pictures\" + ofd.SafeFileName;
                pbPic.ImageLocation = player.Picture;
                if (REPO.CheckIfFileExists(@"\Pictures\" + ofd.SafeFileName))
                {
                    File.Delete(player.Picture);
                }
                File.Copy(ofd.FileName, player.Picture);
                pbPic.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        public void SetFav(string fav)
        {
            if (player.FavPlayer = bool.Parse(fav))
            {
                pbFav.Show();
            }
            else
                pbFav.Hide();
        }

        public Player GetPlayer()
        {
            return player;
        }

    }
}
