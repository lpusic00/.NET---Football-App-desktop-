﻿namespace WindowsForms.Controls
{
    partial class UserControl1
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbPic = new System.Windows.Forms.PictureBox();
            this.PlayerName = new System.Windows.Forms.Label();
            this.Number = new System.Windows.Forms.Label();
            this.Position = new System.Windows.Forms.Label();
            this.Captain = new System.Windows.Forms.Label();
            this.pbFav = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFav)).BeginInit();
            this.SuspendLayout();
            // 
            // pbPic
            // 
            this.pbPic.Location = new System.Drawing.Point(3, 3);
            this.pbPic.Name = "pbPic";
            this.pbPic.Size = new System.Drawing.Size(109, 101);
            this.pbPic.TabIndex = 0;
            this.pbPic.TabStop = false;
            this.pbPic.Click += new System.EventHandler(this.pbPic_Click);
            // 
            // PlayerName
            // 
            this.PlayerName.AutoSize = true;
            this.PlayerName.Location = new System.Drawing.Point(118, 3);
            this.PlayerName.Name = "PlayerName";
            this.PlayerName.Size = new System.Drawing.Size(46, 17);
            this.PlayerName.TabIndex = 2;
            this.PlayerName.Text = "label1";
            // 
            // Number
            // 
            this.Number.AutoSize = true;
            this.Number.Location = new System.Drawing.Point(118, 29);
            this.Number.Name = "Number";
            this.Number.Size = new System.Drawing.Size(46, 17);
            this.Number.TabIndex = 3;
            this.Number.Text = "label2";
            // 
            // Position
            // 
            this.Position.AutoSize = true;
            this.Position.Location = new System.Drawing.Point(118, 57);
            this.Position.Name = "Position";
            this.Position.Size = new System.Drawing.Size(46, 17);
            this.Position.TabIndex = 4;
            this.Position.Text = "label3";
            // 
            // Captain
            // 
            this.Captain.AutoSize = true;
            this.Captain.Location = new System.Drawing.Point(118, 87);
            this.Captain.Name = "Captain";
            this.Captain.Size = new System.Drawing.Size(46, 17);
            this.Captain.TabIndex = 5;
            this.Captain.Text = "label4";
            // 
            // pbFav
            // 
            this.pbFav.Location = new System.Drawing.Point(245, 3);
            this.pbFav.Name = "pbFav";
            this.pbFav.Size = new System.Drawing.Size(39, 39);
            this.pbFav.TabIndex = 7;
            this.pbFav.TabStop = false;
            // 
            // UserControl1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.pbFav);
            this.Controls.Add(this.Captain);
            this.Controls.Add(this.Position);
            this.Controls.Add(this.Number);
            this.Controls.Add(this.PlayerName);
            this.Controls.Add(this.pbPic);
            this.Name = "UserControl1";
            this.Size = new System.Drawing.Size(287, 107);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.UserControl1_MouseDown);
            ((System.ComponentModel.ISupportInitialize)(this.pbPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFav)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbPic;
        private System.Windows.Forms.Label PlayerName;
        private System.Windows.Forms.Label Number;
        private System.Windows.Forms.Label Position;
        private System.Windows.Forms.Label Captain;
        private System.Windows.Forms.PictureBox pbFav;
    }
}
