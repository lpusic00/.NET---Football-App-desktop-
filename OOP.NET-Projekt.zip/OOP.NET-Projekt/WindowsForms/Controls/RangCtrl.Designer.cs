﻿namespace WindowsForms.Controls
{
    partial class RangCtrl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbPic = new System.Windows.Forms.PictureBox();
            this.lblName = new System.Windows.Forms.Label();
            this.lblAppearance = new System.Windows.Forms.Label();
            this.lblCrit = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbPic)).BeginInit();
            this.SuspendLayout();
            // 
            // pbPic
            // 
            this.pbPic.Location = new System.Drawing.Point(3, 3);
            this.pbPic.Name = "pbPic";
            this.pbPic.Size = new System.Drawing.Size(101, 92);
            this.pbPic.TabIndex = 0;
            this.pbPic.TabStop = false;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(119, 3);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(46, 17);
            this.lblName.TabIndex = 1;
            this.lblName.Text = "label1";
            // 
            // lblAppearance
            // 
            this.lblAppearance.AutoSize = true;
            this.lblAppearance.Location = new System.Drawing.Point(119, 42);
            this.lblAppearance.Name = "lblAppearance";
            this.lblAppearance.Size = new System.Drawing.Size(46, 17);
            this.lblAppearance.TabIndex = 2;
            this.lblAppearance.Text = "label2";
            // 
            // lblCrit
            // 
            this.lblCrit.AutoSize = true;
            this.lblCrit.Location = new System.Drawing.Point(119, 78);
            this.lblCrit.Name = "lblCrit";
            this.lblCrit.Size = new System.Drawing.Size(46, 17);
            this.lblCrit.TabIndex = 3;
            this.lblCrit.Text = "label3";
            // 
            // RangCtrl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblCrit);
            this.Controls.Add(this.lblAppearance);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.pbPic);
            this.Name = "RangCtrl";
            this.Size = new System.Drawing.Size(262, 98);
            ((System.ComponentModel.ISupportInitialize)(this.pbPic)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbPic;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblAppearance;
        private System.Windows.Forms.Label lblCrit;
    }
}
