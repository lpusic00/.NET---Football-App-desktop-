﻿using CustomLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms
{
    static class Program
    {
        private const string PATHNationalTeam = @"\NationalTeam.txt";
        private const string PATHLanguage = @"\Language.txt";
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            if (REPO.CheckIfFileExists(PATHLanguage))
            {
                REPO.SetLanguage(REPO.Load(PATHLanguage));
                if (REPO.CheckIfFileExists(PATHNationalTeam))
                {
                    Application.Run(new Players(REPO.Load(PATHNationalTeam)));
                }
                else
                {
                    Application.Run(new NationalTeams());
                }
                    
            }
            else
            {
                Application.Run(new Language());
            }               
        }
    }
}
