﻿using CustomLibrary;
using CustomLibrary.MODEL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsForms.Controls;

namespace WindowsForms
{
    public partial class Players : Form
    {
        private const string PATHplayers = @"\Players.txt";
        List<Player> collectionOfPlayers;
        public Players(string FifaCode)
        {
            InitializeComponent();
            if (REPO.CheckIfFileExists(PATHplayers))
            {
                LoadPlayers();
            }
            else
                LoadDefault(FifaCode);
        }

        private void LoadDefault(string FifaCode)
        {
            collectionOfPlayers = REPO.GetPlayers(FifaCode);

            foreach (Player pl in collectionOfPlayers)
            {
                UserControl1 uc = new UserControl1(pl);

                flpPlayers.Controls.Add(uc);
            }
        }

        private void LoadPlayers()
        {
            collectionOfPlayers = REPO.LoadPlayers();
            foreach (var p in collectionOfPlayers)
            {
                UserControl1 uc = new UserControl1(p);
                if (p.FavPlayer == true)
                {
                    flpFav.Controls.Add(uc);
                }
                else
                {
                    flpPlayers.Controls.Add(uc);
                }
            }
        }

        

        private void flpFav_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Move;
        }

        private void flpFav_DragDrop(object sender, DragEventArgs e)
        {
            if (flpFav.Controls.Count < 3)
            {
                UserControl1 uc = (UserControl1)e.Data.GetData(typeof(UserControl1));
                uc.SetFav("true");
                flpFav.Controls.Add(uc);

            }
            else
                MessageBox.Show("Only 3 or less favourite players can be picked");
        }

        private void flpPlayers_DragDrop(object sender, DragEventArgs e)
        {
            UserControl1 uc = (UserControl1)e.Data.GetData(typeof(UserControl1));
            uc.SetFav("false");
            flpPlayers.Controls.Add(uc);
        }

        private void BtnRang_Click(object sender, EventArgs e)
        {
            Save();
            RangList rc = new RangList(collectionOfPlayers);
            this.Hide();
            rc.ShowDialog();
            this.Close();
        }

        private void Save()
        {
            collectionOfPlayers.Clear();
            
            foreach (UserControl1 uc in flpPlayers.Controls)
            {
                collectionOfPlayers.Add(uc.GetPlayer());
            }

            foreach (UserControl1 uc in flpFav.Controls)
            {
                collectionOfPlayers.Add(uc.GetPlayer());
            }
            REPO.SavePlayers(collectionOfPlayers);
        }

        private void BtnSettings_Click(object sender, EventArgs e)
        {
            Language lang = new Language();
            this.Hide();
            lang.ShowDialog();
            Save();
            Application.Restart();
        }
    }
}
