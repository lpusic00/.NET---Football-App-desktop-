﻿using CustomLibrary;
using CustomLibrary.MODEL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms
{
    public partial class NationalTeams : Form
    {
        private const string PATH = @"\NationalTeam.txt";

        public NationalTeams()
        {            
            InitializeComponent();
            LoadNationalTeams(); 
        }

        private void LoadNationalTeams()
        {
            List<NationalTeam> collection = REPO.GetNationalTeams();
            foreach (var nat in collection)
            {
                cbNationalTeam.Items.Add(nat);
            }
            cbNationalTeam.Show();
        }

        private void cbNationalTeam_SelectedIndexChanged(object sender, EventArgs e)
        {

            {
                NationalTeam natTeam = cbNationalTeam.SelectedItem as NationalTeam;

                REPO.Save(natTeam.FifaCode, PATH);
                REPO.Delete();
                Players playersForm = new Players(natTeam.FifaCode);
                this.Hide();
                playersForm.ShowDialog();
                this.Close();
            }
        }
    }
}
