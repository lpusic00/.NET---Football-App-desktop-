﻿using CustomLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms
{
    public partial class Language : Form
    {
        private const string PATHNat = @"\NationalTeam.txt";
        private const string PATHLanguage = @"\Language.txt";

        public Language()
        {
            Thread t = new Thread(new ThreadStart(StartLoading));
            t.Start();
            Thread.Sleep(5000);
            InitializeComponent();
            t.Abort();
        }

        public void StartLoading()
        {
            Application.Run(new Loading());
        }

        private void BtnENG_Click(object sender, EventArgs e)
        {

            if (REPO.CheckIfFileExists(PATHLanguage))
            {
                REPO.Save("", PATHLanguage);
                REPO.SetLanguage("");
                this.Close();
            }
            else
            {
                REPO.Save("", PATHLanguage);
                REPO.SetLanguage("");
                NextForm();
            }
        }

        private void BtnCRO_Click(object sender, EventArgs e)
        {

            if (REPO.CheckIfFileExists(PATHLanguage))
            {
                REPO.Save("hr", PATHLanguage);
                REPO.SetLanguage("hr");
                this.Close();
            }
            else
            {
                REPO.Save("hr", PATHLanguage);
                REPO.SetLanguage("hr");
                NextForm();
            }
        }

        private void NextForm()
        {
            if (REPO.CheckIfFileExists(PATHNat))
            {
                Players playersForm = new Players(REPO.Load(PATHNat));
                this.Hide();
                playersForm.ShowDialog();
            }
            else
            {
                NationalTeams nationalTeamsForm = new NationalTeams();
                this.Hide();
                nationalTeamsForm.ShowDialog();
            }
            this.Close();
        }
    }
}
