﻿namespace WindowsForms
{
    partial class Language
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Language));
            this.btnENG = new System.Windows.Forms.Button();
            this.btnCRO = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnENG
            // 
            resources.ApplyResources(this.btnENG, "btnENG");
            this.btnENG.Image = global::WindowsForms.Properties.Resources.eng;
            this.btnENG.Name = "btnENG";
            this.btnENG.UseVisualStyleBackColor = true;
            this.btnENG.Click += new System.EventHandler(this.BtnENG_Click);
            // 
            // btnCRO
            // 
            resources.ApplyResources(this.btnCRO, "btnCRO");
            this.btnCRO.Image = global::WindowsForms.Properties.Resources.cro1;
            this.btnCRO.Name = "btnCRO";
            this.btnCRO.UseVisualStyleBackColor = true;
            this.btnCRO.Click += new System.EventHandler(this.BtnCRO_Click);
            // 
            // Language
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsForms.Properties.Resources.stadium;
            this.Controls.Add(this.btnENG);
            this.Controls.Add(this.btnCRO);
            this.Name = "Language";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCRO;
        private System.Windows.Forms.Button btnENG;
    }
}