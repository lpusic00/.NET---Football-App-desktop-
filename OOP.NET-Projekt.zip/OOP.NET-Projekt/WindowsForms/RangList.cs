﻿using CustomLibrary;
using CustomLibrary.MODEL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsForms.Controls;

namespace WindowsForms
{
    public partial class RangList : Form
    {
        private const string PATH = @"\NationalTeam.txt";
        List<Game> gameCollection = REPO.GetGames(REPO.Load(PATH));

        public RangList(List<Player> collectionOfPlayers)
        {
            InitializeComponent();
            ShowGoals(collectionOfPlayers);
            ShowCards(collectionOfPlayers);
            ShowViewers();
        }

        private void ShowViewers()
        {
            gameCollection.Sort();

            foreach (var game in gameCollection)
            {
                listBox1.Items.Add(game);
            }
        }

        private void ShowCards(List<Player> collectionOfPlayers)
        {
            collectionOfPlayers.Sort((x, y) => -x.NumberOfCards.CompareTo(y.NumberOfCards));

            foreach (Player p in collectionOfPlayers)
            {
                RangCtrl rc = new RangCtrl(p, "cards");
                flpCards.Controls.Add(rc);
            }
        }

        private void ShowGoals(List<Player> collectionOfPlayers)
        {
            collectionOfPlayers.Sort();

            foreach (Player p in collectionOfPlayers)
            {
                RangCtrl rc = new RangCtrl(p, "goals");
                flpGoals.Controls.Add(rc);
            }
        }

        private void SetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pageSetupDialog1.ShowDialog();
        }

        private void ChoosePrinterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            printDialog1.ShowDialog();
        }

        Bitmap bmp1, bmp2, bmp3;

        

        private void PrviewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bmp1 = new Bitmap(flpGoals.Width, flpGoals.Height);
            flpGoals.DrawToBitmap(bmp1, new Rectangle(0, 0, flpGoals.Width, flpGoals.Height));

            bmp2 = new Bitmap(flpCards.Width + flpCards.Width, flpCards.Height);
            flpCards.DrawToBitmap(bmp2, new Rectangle(0, 0, flpCards.Width, flpCards.Height));

            bmp3 = new Bitmap(listBox1.Width, listBox1.Height);
            listBox1.DrawToBitmap(bmp3, new Rectangle(0, 0, listBox1.Width, listBox1.Height));

            printPreviewDialog1.ShowDialog();
        }

        private void PrintToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            printDocument1.Print();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(bmp1, e.MarginBounds.Left, e.MarginBounds.Top);
            e.Graphics.DrawImage(bmp2, 2 * e.MarginBounds.Left + flpGoals.Width, e.MarginBounds.Top);
            e.Graphics.DrawImage(bmp3, e.MarginBounds.Left, 2 * e.MarginBounds.Top + flpGoals.Height);
      
        }
    }
}
