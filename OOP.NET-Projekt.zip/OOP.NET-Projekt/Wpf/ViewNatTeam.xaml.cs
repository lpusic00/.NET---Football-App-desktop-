﻿using CustomLibrary;
using CustomLibrary.MODEL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf
{
    /// <summary>
    /// Interaction logic for ViewNatTeam.xaml
    /// </summary>
    public partial class ViewNatTeam : Window
    {
        public ViewNatTeam(string FifaCode, List<NationalTeam> collection)
        {
            InitializeComponent();
            Load(FifaCode, collection);
        }

        private void Load(string FifaCode, List<NationalTeam> collection)
        {
            NationalTeam natTeam = REPO.GetNationalTeamWPF(FifaCode, collection);
            lblName.Content = natTeam.Country;
            lblFifaCode.Content = natTeam.FifaCode;
            lblGames.Content = natTeam.GamesPlayed;
            lblRatio.Content = natTeam.Wins + " | " + natTeam.Draws + " | " + natTeam.Losses;
            lblGoals.Content = natTeam.GoalsFor + " | " + natTeam.GoalsAgainst + " | " + natTeam.GoalDifferential;
        }
    }
}
