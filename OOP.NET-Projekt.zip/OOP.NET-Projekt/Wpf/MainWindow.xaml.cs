﻿using CustomLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Wpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private const string PATHLanguage = @"\Language.txt";
        public MainWindow()
        {
            InitializeComponent();
            if (REPO.CheckIfFileExists(PATHLanguage))
            {
                spLang.Visibility = Visibility.Hidden;
                spSize.Visibility = Visibility.Visible;
            }
        }

        private void BtnCRO_Click(object sender, RoutedEventArgs e)
        {
            REPO.Save("hr", PATHLanguage);
            REPO.SetLanguage("hr");
            spLang.Visibility = Visibility.Hidden;
            spSize.Visibility = Visibility.Visible;
        }

        private void BtnENG_Click(object sender, RoutedEventArgs e)
        {
            REPO.Save("", PATHLanguage);
            REPO.SetLanguage("");
            spLang.Visibility = Visibility.Hidden;
            spSize.Visibility = Visibility.Visible;
        }

        private void BtnNormal_Click(object sender, RoutedEventArgs e)
        {
            REPO.WindowSize("Normal", PATHLanguage);
            spSize.Visibility = Visibility.Hidden;

            Loading window = new Loading();
            //NationalTeams window = new NationalTeams();
            this.Hide();
            window.ShowDialog();
            this.Close();
        }

        private void BtnFull_Click(object sender, RoutedEventArgs e)
        {
            REPO.WindowSize("Max", PATHLanguage);
            spSize.Visibility = Visibility.Hidden;

            Loading window = new Loading();
            //NationalTeams window = new NationalTeams();
            this.Hide();
            window.ShowDialog();
            this.Close();
        }

    }
}
