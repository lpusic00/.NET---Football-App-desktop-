﻿using CustomLibrary;
using CustomLibrary.MODEL;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Wpf.Controls;

namespace Wpf
{
    /// <summary>
    /// Interaction logic for NationalTeams.xaml
    /// </summary>
    public partial class NationalTeams : Window
    {
        private const string PATH = @"\NationalTeam.txt";
        private string CODE = REPO.Load(PATH);
        private List<NationalTeam> collection = REPO.GetNationalTeams();

        public NationalTeams()
        {
            InitializeComponent();
            string line = REPO.Size();
            if (line == "Normal")
            {
                WindowState = WindowState.Normal;
            }
            else
                WindowState = WindowState.Maximized;
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            File.Delete(REPO.DIR + @"\Language.txt");
            MainWindow window = new MainWindow();
            this.Hide();
            window.ShowDialog();
            this.Close();
        }

        private void CbHome_Loaded(object sender, RoutedEventArgs e)
        {
            int index = 0;
            foreach (var item in collection)
            {
                cbHome.Items.Add(item);
                if (item.FifaCode == CODE)
                {
                    cbHome.SelectedIndex = index;
                }
                index++;
            }
        }

        private void LoadField()
        {
            List<Game> list = REPO.GetGames(CODE);
            NationalTeam away = cbAway.SelectedItem as NationalTeam;

            foreach (var game in list)
            {
                if (game.HomeTeam.Code == away.FifaCode)
                {
                    LoadHomeTeam(game.AwayTeamStatistics.StartingEleven, game.AwayTeamEvents);
                    LoadAwayTeam(game.HomeTeamStatistics.StartingEleven, game.HomeTeamEvents);
                    lblHomeGoals.Content = game.AwayTeam.Goals;
                    lblAwayGoals.Content = game.HomeTeam.Goals;
                    return;
                }
                else if (game.AwayTeam.Code == away.FifaCode)
                {
                    LoadHomeTeam(game.HomeTeamStatistics.StartingEleven, game.HomeTeamEvents);
                    LoadAwayTeam(game.AwayTeamStatistics.StartingEleven, game.AwayTeamEvents);
                    lblHomeGoals.Content = game.HomeTeam.Goals;
                    lblAwayGoals.Content = game.AwayTeam.Goals;
                    return;
                }
            }
        }

        private void LoadHomeTeam(List<Player> players, List<TeamEvents> events)
        {
            if (REPO.CheckIfFileExists(@"\Players.txt"))
            {
                List<Player> savedPlayers = REPO.LoadPlayers();
                savedPlayers = REPO.GameStatistics(events, savedPlayers);

                foreach (var savedPlayer in savedPlayers)
                {
                    foreach (var player in players)
                    {
                        if (player.Name == savedPlayer.Name)
                        {
                            savedPlayer.Captain = player.Captain;
                            PlayerControl uc = new PlayerControl(savedPlayer);
                            if (savedPlayer.Position == "Goalie")
                            {
                                spHomeG.Children.Add(uc);
                            }
                            else if (savedPlayer.Position == "Defender")
                            {
                                spHomeD.Children.Add(uc);
                            }
                            else if (savedPlayer.Position == "Midfield")
                            {
                                spHomeM.Children.Add(uc);
                            }
                            else
                            {
                                spHomeF.Children.Add(uc);
                            }
                        }
                    }
                }
            }
            else
            {
                players = REPO.GameStatistics(events, players);
                foreach (Player player in players)
                {
                    PlayerControl uc = new PlayerControl(player);
                    if (player.Position == "Goalie")
                    {
                        spHomeG.Children.Add(uc);
                    }
                    else if (player.Position == "Defender")
                    {
                        spHomeD.Children.Add(uc);
                    }
                    else if (player.Position == "Midfield")
                    {
                        spHomeM.Children.Add(uc);
                    }
                    else
                    {
                        spHomeF.Children.Add(uc);
                    }
                }
            }
        }

        private void LoadAwayTeam(List<Player> players, List<TeamEvents> events)
        {
            players = REPO.GameStatistics(events, players);
            foreach (Player player in players)
            {
                PlayerControl uc = new PlayerControl(player);
                if (player.Position == "Goalie")
                {
                    spAwayG.Children.Add(uc);
                }
                else if (player.Position == "Defender")
                {
                    spAwayD.Children.Add(uc);
                }
                else if (player.Position == "Midfield")
                {
                    spAwayM.Children.Add(uc);
                }
                else
                {
                    spAwayF.Children.Add(uc);
                }
            }
        }

        private void CbHome_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            lblHomeGoals.Content = 0;
            lblAwayGoals.Content = 0;
            NationalTeam natTeam = cbHome.SelectedItem as NationalTeam;
            if (natTeam.FifaCode != CODE)
            {
                REPO.Delete();
            }
            ViewNatTeam window = new ViewNatTeam(natTeam.FifaCode, collection);
            window.ShowDialog();
            REPO.Save(natTeam.FifaCode, PATH);
            cbAway.Items.Clear();
            LoadAway();
        }

        private void CbAway_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (spHomeG.Children.Count != 0)
            {
                spHomeG.Children.Clear();
                spHomeD.Children.Clear();
                spHomeM.Children.Clear();
                spHomeF.Children.Clear();
                spAwayG.Children.Clear();
                spAwayD.Children.Clear();
                spAwayM.Children.Clear();
                spAwayF.Children.Clear();
            }
            if (!(cbAway.SelectedIndex == -1))
            {
                NationalTeam natTeam = cbAway.SelectedItem as NationalTeam;
                ViewNatTeam window = new ViewNatTeam(natTeam.FifaCode, collection);
                window.ShowDialog();
                LoadField();
            }
        }

        private void LoadAway()
        {
            CODE = REPO.Load(PATH);
            List<Game> listaUtakmica = REPO.GetGames(CODE);
            foreach (var item in listaUtakmica)
            {
                if (item.HomeTeam.Code == CODE)
                {
                    cbAway.Items.Add(GetNAT(item.AwayTeam.Code));
                }
                else
                {
                    cbAway.Items.Add(GetNAT(item.HomeTeam.Code));
                }
            }
        }

        private NationalTeam GetNAT(string FifaCode)
        {
            foreach (var i in collection)
            {
                if (FifaCode == i.FifaCode)
                {
                    return i;
                }
            }
            return null;
        }
    }
}
