﻿using CustomLibrary.MODEL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf
{
    /// <summary>
    /// Interaction logic for ViewPlayer.xaml
    /// </summary>
    public partial class ViewPlayer : Window
    {
        public ViewPlayer(Player player)
        {
            InitializeComponent();
            Load(player);
        }

        private void Load(Player player)
        {
            lblName.Content = player.Name;
            lblNumber.Content = player.ShirtNumber;
            lblPosition.Content = player.Position;
            imgPlayer.Source = new BitmapImage(new Uri(player.Picture));
            lblGoals.Content = player.GameGoals;
            lblCards.Content = player.GameCards;
            lblCaptain.Content = player.Captain;
        }
    }
}
